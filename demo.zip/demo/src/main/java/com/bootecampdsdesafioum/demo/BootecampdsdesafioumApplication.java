package com.bootecampdsdesafioum.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootecampdsdesafioumApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootecampdsdesafioumApplication.class, args);
	}

}
